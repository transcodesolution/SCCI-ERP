import Header from "../Commom/Header"; 
import Sidebar from "../Commom/Sidebar"; 


function MainComponent() {
    return (
       <div>
        <Header/>
        <Sidebar/>
       </div>
    );
}

export default MainComponent;










