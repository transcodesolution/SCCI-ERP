import React from 'react'

function Dashboard() {
  return (
    <div style={{ marginTop: "65px" }}>
      <h1>Dashboard</h1>
    </div>
  )
}

export default Dashboard;