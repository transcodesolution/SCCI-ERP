import React from 'react'
const PrintBill = ({ component }) => {
    return (
        <>
            <div>{component}</div>
        </>
    );
}
export default PrintBill