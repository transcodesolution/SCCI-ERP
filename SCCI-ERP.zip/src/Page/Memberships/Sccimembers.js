import { Box, Flex, Input, Select, Stack } from '@chakra-ui/react';
import Membercard from '../../Components/Commom/Card';
import { SimpleGrid } from '@chakra-ui/react'
import React, { useEffect, useState } from 'react';
import { ApiPost } from '../../Api/ApiData';
import { AiOutlinePlus } from 'react-icons/ai';
import { Button, Divider, Modal, ModalBody, ModalCloseButton, ModalContent, ModalFooter, ModalHeader, ModalOverlay, useDisclosure } from '@chakra-ui/react'
import { toast } from 'react-toastify'
import Pagination from '@mui/material/Pagination';
import { TableContainer, Table, TableHead, TableRow, TableCell, TableBody, TablePagination } from '@material-ui/core';
import { useDispatch } from "react-redux";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

import 'jspdf-autotable';
// import { read, utils, writeFile } from 'xlsx';
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';


import {
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
} from '@chakra-ui/react'

const Sccimembers = () => {
  const { isOpen, onOpen, onClose } = useDisclosure()
  const dispatch = useDispatch();
  const finalRef = React.useRef(null)
  const [page_count, setPageCount] = useState(1)
  const [pages, setPages] = useState(1)

  const getFilterMammbet = () => {
    toast.success('Transaction Added')
    onClose()
    ApiPost('/admin/member/get/all', {
      "page": page,
      "limit": Number(search.limit),
      "typefilter": search.category,
    }).then((response) => {
      setMembers(response?.data?.data?.member_data)
      // console.log("@@@@@@@@@@@@", response)
      console.log("######", members)



    })
  }

  const handlePageChange = (event, value) => {
    setMembers(value);
  };


  const [search, setSearch] = useState({
    name: "",
    category: "",
    limit: "",
  })

  const [page, setPage] = useState(1)
  const [limit, setLimit] = useState(10)
  const [typefilter, setTypeFilter] = useState("");
  const [members, setMembers] = useState([])
  const [categories, setCategories] = useState([])
  // const [pageCount, setCountPage] = useState(1);
  const handleChange = (event) => {
    let { name, value } = event.target
    setSearch((old) => {
      return {
        ...old,
        [name]: value
      }
    })
  }

  const getAllMembers = () => {
    ApiPost('/admin/member/get/all', {
      "page": page,
      "limit": limit,
      "typefilter": typefilter,
    }).then((response) => {
      setMembers(response?.data?.data?.member_data)
      console.log("@@@@@@@@@@@@!!!!!!!!", response)
    })
  }
  const getAllCategory = async () => {
    await ApiPost('/admin/member/type/get/all', { search: "" }).then((response) => {
      setCategories(response?.data?.data)
      console.log("***********", categories)
    })
  }


  useEffect(() => {
    getAllMembers()
    getAllCategory()
    return () => {

    }
  }, [])

  console.log(search)


  useEffect(() => {
    getFilterMammbet();
  }, [members])




  const handleDownload = () => {
    const unit = 'pt';
    const size = 'A4'; // Use A1, A2, A3 or A4
    const orientation = 'portrait'; // portrait or landscape

    const marginLeft = 40;
    const doc = new jsPDF(orientation, unit, size);

    doc.setFontSize(15);
    doc.setFont('helvetica', 'bold');
    doc.text('API Data', marginLeft, 40);

    const headers = [['FirstName', 'MiddleName', 'LastName', 'Phone', 'Email']];
    const data = members.map(post => [post.firstName, post.middleName, post.lastName, post.phone, post.email]);

    doc.autoTable({
      head: headers,
      body: data,
      startY: 50,
      styles: {
        fontSize: 12,
        cellPadding: 6,
        overflow: 'linebreak',
      },
    });

    doc.save('api-data.pdf');
  };



  const handleXLSX = () => {
    const headers = [['FirstName', 'MiddleName', 'LastName', 'Phone', 'Email']];
    const data = members.map(post => [post.firstName, post.middleName, post.lastName, post.phone, post.email]);
    const worksheet = XLSX.utils.aoa_to_sheet([...headers, ...data]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'API Data');
    const xlsxBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    saveAs(new Blob([xlsxBuffer]), 'api-data.xlsx');
  };


  return (
    <>

      <div style={{ backgroundColor: "#fff", marginTop: "65px", padding: "20px", borderRadius: "10px", }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: "100%" }}>
          <label style={{ width: "50%", display: 'block' }}>
            <Input bg={'whiteAlpha.600'} type="text" placeholder="Search" name='name' onChange={handleChange} />
          </label>

          <div style={{ display: 'flex' }}>
            <Menu>
              <MenuButton as={Button}   >
                Export
              </MenuButton>
              <MenuList>
                <MenuItem><button onClick={handleDownload}>PDF</button></MenuItem>
                <MenuItem><button onClick={handleXLSX}> XLSX</button></MenuItem>
              </MenuList>
            </Menu>

            <div style={{ marginLeft: '15px' }}>
              <Box textAlign={'center'}>
                <Button onClick={onOpen} > <AiOutlinePlus /> &nbsp; Filter Details  </Button>
              </Box>
            </div>
          </div>

        </div>
        <Box style={{ marginTop: '20px' }}>
          <SimpleGrid columns={[1, 2, 2, 2, 3, 5, 5]} spacing={5}>
            {
              members.map((data) => <Membercard data={data} />)
            }
          </SimpleGrid>
        </Box>
        <div className="student_pagination">
          <div className="pagination_block">
            <Stack sx={{ mt: "2rem", ml: "27rem" }} spacing={2}>
              <div class="d-flex justify-content-between pt-10 align-items-center">
                <div className="my-2">
                  <Pagination
                    color="standard"
                    count={page_count}
                    members={members}
                    onChange={handlePageChange}
                  />
                </div>
                <div class="my-2 my-md-0">
                  <div class="d-flex align-items-center pagination-drpdown">
                    <select
                      class="form-control pagination-drpdown1 dropdownPage"
                      id="kt_datatable_search_status"
                      onChange={(e) => {
                        setLimit(parseInt(e.target.value));
                        console.log(e.target.value);
                      }}
                      value={limit}
                    >
                      <option value={10}>10</option>
                      <option value={20}>20</option>
                      <option value={30}>30</option>
                      <option value={50}>50</option>
                    </select>
                  </div>
                </div>
              </div>
            </Stack>
          </div>
        </div>

      </div>
      <Modal finalFocusRef={finalRef} isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>SCCI MEMBERS-DETAILS</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Divider />
            <Select placeholder='Select option' name='category' onChange={handleChange} >
              {
                categories.map((data) => <option value={data?._id}>{data?.name}</option>)
              }

            </Select>
            <Input type='number' mt={4} placeholder='Limit' name='limit' value={search.limit} onChange={handleChange} />
          </ModalBody>
          <ModalFooter>
            <Button colorScheme='blue' mr={3} onClick={onClose}>
              Close
            </Button>
            <Button colorScheme='green' onClick={() => getFilterMammbet()}>Apply</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>

    </>

  )
}

export default Sccimembers;
























// <Flex mt={4} justifyContent={"space-between"}>
// <Box>
//   <Stack spacing={2}>
//     <div>
//       <TablePagination
//         component="div"
//         count={totalCount}
//         page={pages}
//         onChangePage={handleChangePage}
//         rowsPerPage={pageSize}
//         onChangeRowsPerPage={handleChangeRowsPerPage}
//         rowsPerPageOptions={[5, 10, 15]}
//       />
//     </div>


//     <div class="my-2 my-md-0">
//       <div class="d-flex align-items-center pagination-drpdown">
//         <select
//           class="form-control pagination-drpdown1 dropdownPage"
//           id="kt_datatable_search_status"
//           onChange={(e) => {
//             setLimit(parseInt(e.target.value));
//             console.log(e.target.value);
//           }}
//           value={limit}
//         >
//           <option value={10}>10</option>
//           <option value={20}>20</option>
//           <option value={30}>30</option>
//           <option value={50}>50</option>
//         </select>
//       </div>
//     </div>
//   </Stack>
// </Box>
// </Flex>


















// import * as React from 'react';
// import Pagination from '@mui/material/Pagination';
// import Stack from '@mui/material/Stack';

// export default function PaginationRounded() {
//   return (
//     <Stack spacing={2}>
//       <Pagination count={10} shape="rounded" />
//       <Pagination count={10} variant="outlined" shape="rounded" />
//     </Stack>
//   );
// }







